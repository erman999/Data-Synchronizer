/**
 * @ Author: Erman İlçin
 * @ Create Time: 2024-04-16 13:53:20
 * @ Modified by: Erman İlçin
 * @ Modified time: 2024-06-28 14:38:06
 * @ Description: Data Manager Project
 */

const util = require('node:util');
const utilOptions = { breakLength: Infinity, colors: true };

const app = {
  io: null,
  users: [],
  clients: [],
  mysqlPool: null,
  credentials: [],
  getIpAdresses: function () {
    const os = require("os");
    let ip = {};
    const networkInterfaces = os.networkInterfaces();
    Object.keys(networkInterfaces).forEach((name, index) => {
      networkInterfaces[name].forEach((item) => {
        if (!item.internal) {
          if (item.family === "IPv4") ip.v4 = item.address;
          if (item.family === "IPv6") ip.v6 = item.address;
        }
      });
    });
    return ip;
  },
  createUser: function (data) {
    const user = {
      userId: data.userId ?? null,
      name: data.name ?? null,
      auth: data.auth ?? null,
      ip: data.ip ?? null,
      sockets: data.sockets ?? [],
    };
    return user;
  },
  createClient: function (data) {
    const client = data;
    client.machineId = data.machineId ?? null;
    client.name = data.name ?? 'Makina';
    client.ip = data.ip ?? null;
    client.totalSync = data.totalSync ?? null;
    client.appVersion = data.appVersion ?? null;
    client.platform = data.platform ?? null;
    client.arch = data.arch ?? null;
    client.lts = data.lts ?? null;
    client.electron = data.electron ?? null;
    client.node = data.node ?? null;
    client.chrome = data.chrome ?? null;
    client.sockets = data.sockets ?? [];
    client.ready = false;
    client.syncInfo = false;
    return client;
  },
  isIpExists: function (ip, arr) {
    return arr.some(item => item.ip === ip);
  },
  findClientByIp: function (ip, arr) {
    return arr.find(item => item.ip === ip);
  },
  sqlQuery: async function (pool, query) {
    try {
      const [rows, fields] = await pool.query(query);
      return { result: true, response: rows };
    } catch (e) {
      return { result: false, response: e };
    }
  },
  mysqlSanitizeStatement: function (statement, rename = null) {
    // Replace whitespaces with single space
    statement = statement.replace(/\s+/g, ' ');
    // Find first and last parentheses
    let firstIndex = statement.indexOf("(");
    let lastIndex = statement.lastIndexOf(")");
    // Get beginning of the statement
    let statement1 = rename ?? statement.substring(0, firstIndex).trim();
    // Get text between parentheses
    let statement2 = statement.substring(firstIndex + 1, lastIndex).trim();
    // Explode string by comma
    let explode1 = statement2.split(",");
    // Remove CHARACTER SET  & COLLATE
    let explode2 = explode1.map((item) => item.trim().replace(/CHARACTER SET\ .*?\ /, "").replace(/COLLATE\ .*?\ /, ""));
    // Remove unwanted table links (but these are counted as errors)
    let explode3 = explode2.filter((item) => !(item.includes('CONSTRAINT ') || item.includes('FOREIGN KEY ') || item.includes('REFERENCES ')));
    return {
      statement: statement1 + ' ( ' + explode3.join(', ') + ' )',
      errors: explode2.length - explode3.length
    };
  },
  convertRowsToStructure: function (rows) {
    // console.log(rows);
    let serverStructure = [];
    rows.forEach((row, i) => {
      // Check if database exists
      const checkDb = serverStructure.some((el) => el.database === row.clientDatabase);
      // If not
      if (!checkDb) {
        // Create same structure
        const obj = {
          database: row.clientDatabase,
          serverDatabase: row.serverDatabase,
          tables: [{ table: row.clientTable, alias: '`' + row.serverDatabase + '` . `' + row.serverTable + '`' }]
        };
        // Add to new array
        serverStructure.push(obj);
      } else {
        // Add tables to current item
        const obj = serverStructure.find((el) => el.database === row.clientDatabase);
        obj.tables.push({ table: row.clientTable, alias: '`' + row.serverDatabase + '` . `' + row.serverTable + '`' });
      }
    });
    return serverStructure;
  },
  generateRandomString: function (length) {
    // const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    const characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    const charactersLength = characters.length;
    for (let i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
  },
  sum: function (items, prop) {
    return items.reduce(function (a, b) {
      return a + b[prop];
    }, 0);
  }
};

async function startApp() {

  app.io = await require("./server.js");
  app.mysqlPool = await require("./database.js");

  const machines = await app.sqlQuery(app.mysqlPool, 'SELECT * FROM `data_manager`.`machines`;');

  for (const row of machines.response) {
    const client = app.createClient(row);
    app.clients.push(client);
    const sync_mysql = await app.sqlQuery(app.mysqlPool, 'SELECT * FROM `data_manager`.`sync_mysql` WHERE `machineId` = ' + client.machineId);
    client.sync_mysql = sync_mysql.response;
  }

  const credentials = await app.sqlQuery(app.mysqlPool, 'SELECT * FROM `data_manager`.`credentials`;');
  app.credentials = credentials.response;

  socketServer(app.io);

  setInterval(async () => {
    for (const client of app.clients) {

      // console.log({ machineId: client.machineId, ready: client.ready, sockets: client.sockets.length, mysql: client.sync_mysql.length });

      if (!client.ready) continue;
      if (!(client.sockets.length > 0)) continue;
      if (!(client.sync_mysql.length > 0)) continue;

      // Ask for current status
      client.sockets.forEach((socketId, i) => {
        app.io.to(socketId).emit('sync-mysql', client.sync_mysql);
      });

      // Calculate sync percentage
      let totalServerRecords = app.sum(client.sync_mysql, 'serverLastRecord');
      let totalClientRecords = app.sum(client.sync_mysql, 'clientLastRecord');
      client.totalSync = Math.floor((totalServerRecords / totalClientRecords) * 100 * 10) / 10;
      // console.log(client.totalSync, totalServerRecords, totalClientRecords);

      if (client.totalSync < 100) client.syncInfo = true;

      if (client.syncInfo) {
        console.log(totalServerRecords, totalClientRecords, client.totalSync);
        app.io.emit('sync-data', client);
        await app.sqlQuery(app.mysqlPool, 'UPDATE `data_manager`.`machines` SET `totalSync` = ' + client.totalSync + ' WHERE `machineId` = ' + client.machineId);
        if (client.totalSync === 100) client.syncInfo = false;
      }

    }
  }, 1000 * 10);

  console.log("Server IP Adresses:", app.getIpAdresses());

}

startApp();

function socketServer(io) {

  io.on("connection", (socket) => {
    // Get client ip address
    const ipAddress = socket.handshake.address;
    // Inspect connection
    console.log(util.inspect({ channel: 'connection', socketId: socket.id, ip: ipAddress }, utilOptions));


    // Return live list
    socket.on('live-list', (data) => {
      socket.emit('live-list', { action: 'full-list', users: app.users, clients: app.clients });
    });


    // Identify connection
    socket.on('identify', async (data) => {
      // Inspect connection
      console.log(util.inspect({ channel: 'identify', socketId: socket.id, ip: ipAddress, type: data.type }, utilOptions));

      // New user connection
      if (data.type === 'user') {
        // Check if this ip already connected
        const isIpExists = app.isIpExists(ipAddress, app.users);

        if (!isIpExists) {
          // Create a new user object
          data.ip = ipAddress;
          data.sockets = [socket.id];
          const user = app.createUser(data);
          // Add current socket to user sockets
          app.users.push(user);
          // Update live list
          io.emit('live-list', { action: 'add', type: data.type, user: user });
        }

        if (isIpExists) {
          // Find user
          const user = app.findClientByIp(ipAddress, app.users);
          // Add current socket to user sockets
          user.sockets.push(socket.id);
          // Inspect connetion
          console.log(util.inspect({ channel: 'identify', socketId: socket.id, ip: user.ip, type: data.type, sockets: user.sockets.length }, utilOptions));
          // Update live list
          io.emit('live-list', { action: 'update', type: data.type, user: user });
        }
      }

      // New client connection
      if (data.type === 'machine') {
        // Check if this ip already connected
        const isIpExists = app.isIpExists(ipAddress, app.clients);

        if (!isIpExists) {
          // Create a new client object
          data.ip = ipAddress;
          data.sockets = [socket.id];
          const client = app.createClient(data);
          // Add current socket to client sockets
          app.clients.push(client);
          // Update live list
          io.emit('live-list', { action: 'add', type: data.type, client: client });
        }

        if (isIpExists) {
          // Find client
          const client = app.findClientByIp(ipAddress, app.clients);
          // Add current socket to client sockets
          client.sockets.push(socket.id);
          // Inspect connetion
          console.log(util.inspect({ channel: 'identify', socketId: socket.id, ip: client.ip, type: data.type, sockets: client.sockets.length }, utilOptions));
          // Update live list
          io.emit('live-list', { action: 'update', type: data.type, client: client });
          // Client ready package
          credentials = app.credentials.find((item) => item.machineId == client.machineId);
          if (credentials != undefined) {
            const pack = {};
            pack.client = client;
            pack.credentials = credentials;
            socket.emit('ready', pack);
          }
        }
      }

    });


    // Update client ready status
    socket.on('ready', async (data) => {
      // console.log(data);
      const client = app.clients.find((el) => el.machineId == data.client.machineId);
      if (client !== undefined) {
        client.ready = data.client.ready;
        client.appInfo = data.client.appInfo;
        console.log('Ready status:', { machineId: client.machineId, ready: client.ready });

        try {
          const sql = 'UPDATE `data_manager`.`machines` SET `platform`=?,`arch`=?,`lts`=?,`electron`=?,`node`=?,`chrome`=? WHERE `machineId` = ?';
          const values = [client.appInfo.platform, client.appInfo.arch, client.appInfo.release.lts, client.appInfo.versions.electron, client.appInfo.versions.node, client.appInfo.versions.chrome, data.client.machineId];
          const [result, fields] = await app.mysqlPool.execute(sql, values);
        } catch (err) {
          console.log(err);
        }

      }
    });


    // Listen for client disconnection
    socket.on("disconnect", (reason) => {
      console.log({ channel: 'disconnect', socketId: socket.id });
      // For users
      if (app.isIpExists(ipAddress, app.users)) {
        // Filter users from same ipAddress
        const filteredUsers = app.users.filter(user => user.ip === ipAddress);
        // Check for each user object
        filteredUsers.forEach((user, i) => {
          // Find disconnected socket
          let socketIndex = user.sockets.indexOf(socket.id);
          // Remove disconnected socket from user.sockets
          if (socketIndex > -1) {
            // Drop socket
            user.sockets.splice(socketIndex, 1);
            // Update live list
            io.emit('live-list', { action: 'update', type: 'user', user: user });
            // Inspect connetion
            console.log(util.inspect({ channel: 'disconnect', socketId: socket.id, ip: user.ip, type: 'user', sockets: user.sockets.length }, utilOptions));
            // Remove whole user object if no sockets connected
            if (user.sockets.length === 0) {
              // Update live list
              io.emit('live-list', { action: 'remove', type: 'user', user: user });
              // Remove user from server
              app.users.splice(app.users.indexOf(user), 1);
            }
          }
        });
      }
      // For machines
      if (app.isIpExists(ipAddress, app.clients)) {
        // Filter clients from same ipAddress
        const filteredClients = app.clients.filter(client => client.ip === ipAddress);
        // Check for each user object
        filteredClients.forEach((client, i) => {
          // Find disconnected socket
          let socketIndex = client.sockets.indexOf(socket.id);
          // Remove disconnected socket from client.sockets
          if (socketIndex > -1) {
            // Drop socket
            client.sockets.splice(socketIndex, 1);
            // Update live list
            io.emit('live-list', { action: 'update', type: 'machine', client: client });
            // Inspect connetion
            console.log(util.inspect({ channel: 'disconnect', socketId: socket.id, ip: client.ip, type: 'machine', sockets: client.sockets.length }, utilOptions));
          }
        });
      }
    });


    // Server run
    socket.on('server-run', async (data) => {

      switch (data.channel) {

        case 'mysql-save-structure':

          // Create new records
          if (data.serverStructure.length === 0) {
            for (const userItem of data.userStructure) {
              // Server database alias
              const serverDatabaseName = userItem.database + '_' + app.generateRandomString(5);
              // Create database
              await app.sqlQuery(app.mysqlPool, `CREATE DATABASE \`${serverDatabaseName}\`;`);
              // New table for each item
              for (const userTable of userItem.tables) {
                // Find client database item
                const clientItem = data.clientStructure.find((el) => el.database === userItem.database);
                if (clientItem !== undefined) {
                  // Find client table item
                  const clientTable = clientItem.tables.find((el) => el.table === userTable.table);
                  if (clientTable !== undefined) {
                    // Adjust create command
                    let createCommand = app.mysqlSanitizeStatement(clientTable.createCommand);
                    createCommand = createCommand.statement.replace('CREATE TABLE `', 'CREATE TABLE `' + serverDatabaseName + '`.`');
                    // Create client table on server
                    const createTableSql = await app.sqlQuery(app.mysqlPool, createCommand);
                  }
                }
                // Create server structure
                await app.sqlQuery(app.mysqlPool, 'INSERT INTO `data_manager`.`sync_mysql`(`machineId`, `clientDatabase`, `clientTable`, `serverDatabase`, `serverTable`, `primaryCol`, `timestampCol`, `clientLastRecord`, `serverLastRecord`, `numRowsToCopy`, `cycleDelay`, `isVisible`) VALUES ' + `(${data.machineId}, '${userItem.database}', '${userTable.table}', '${serverDatabaseName}', '${userTable.table}', '${userTable.primary}', '', 0, 0, 100, 1000, 1)`);
              }
            }
          }

          // Delete old records and create new ones
          if (data.serverStructure.length > 0) {

            // Remove all tables
            const rows = await app.sqlQuery(app.mysqlPool, 'SELECT * FROM `data_manager`.`sync_mysql` WHERE `machineId` = ' + data.machineId);
            if (rows.result) {
              for (const row of rows.response) {
                await app.sqlQuery(app.mysqlPool, `DROP TABLE IF EXISTS \`${row.serverDatabase}\`.\`${row.serverTable}\`;`);
              }
            }

            // Clear previous structure
            await app.sqlQuery(app.mysqlPool, 'DELETE FROM `data_manager`.`sync_mysql` WHERE `machineId` = ' + data.machineId);

            for (const userItem of data.userStructure) {
              // Find client database item
              const serverItem = data.serverStructure.find((el) => el.database === userItem.database);
              if (serverItem === undefined) {
                // Server database alias
                const serverDatabaseName = userItem.database + '_' + app.generateRandomString(5);
                // Create database
                await app.sqlQuery(app.mysqlPool, `CREATE DATABASE \`${serverDatabaseName}\`;`);
                // New table for each item
                for (const userTable of userItem.tables) {
                  // Find client database item
                  const clientItem = data.clientStructure.find((el) => el.database === userItem.database);
                  if (clientItem !== undefined) {
                    // Find client table item
                    const clientTable = clientItem.tables.find((el) => el.table === userTable.table);
                    if (clientTable !== undefined) {
                      // Adjust create command
                      let createCommand = app.mysqlSanitizeStatement(clientTable.createCommand);
                      createCommand = createCommand.statement.replace('CREATE TABLE `', 'CREATE TABLE `' + serverDatabaseName + '`.`');
                      // Create client table on server
                      const createTableSql = await app.sqlQuery(app.mysqlPool, createCommand);
                    }
                  }
                  // Create server structure
                  await app.sqlQuery(app.mysqlPool, 'INSERT INTO `data_manager`.`sync_mysql`(`machineId`, `clientDatabase`, `clientTable`, `serverDatabase`, `serverTable`, `primaryCol`, `timestampCol`, `clientLastRecord`, `serverLastRecord`, `numRowsToCopy`, `cycleDelay`, `isVisible`) VALUES ' + `(${data.machineId}, '${userItem.database}', '${userTable.table}', '${serverDatabaseName}', '${userTable.table}', '${userTable.primary}', '', 0, 0, 100, 1000, 1)`);
                }
              }

              if (serverItem !== undefined) {
                // Get alias database name
                const serverDatabaseName = serverItem.serverDatabase;
                // New table for each item
                for (const userTable of userItem.tables) {
                  // Find client database item
                  const clientItem = data.clientStructure.find((el) => el.database === userItem.database);
                  if (clientItem !== undefined) {
                    // Find client table item
                    const clientTable = clientItem.tables.find((el) => el.table === userTable.table);
                    if (clientTable !== undefined) {
                      // Adjust create command
                      let createCommand = app.mysqlSanitizeStatement(clientTable.createCommand);
                      createCommand = createCommand.statement.replace('CREATE TABLE `', 'CREATE TABLE `' + serverDatabaseName + '`.`');
                      // Create client table on server
                      const createTableSql = await app.sqlQuery(app.mysqlPool, createCommand);
                    }
                  }
                  // Create server structure
                  await app.sqlQuery(app.mysqlPool, 'INSERT INTO `data_manager`.`sync_mysql`(`machineId`, `clientDatabase`, `clientTable`, `serverDatabase`, `serverTable`, `primaryCol`, `timestampCol`, `clientLastRecord`, `serverLastRecord`, `numRowsToCopy`, `cycleDelay`, `isVisible`) VALUES ' + `(${data.machineId}, '${userItem.database}', '${userTable.table}', '${serverDatabaseName}', '${userTable.table}', '${userTable.primary}', '', 0, 0, 100, 1000, 1)`);
                }
              }
            }
          }

          // Update client object
          const client = app.clients.find((client) => client.machineId === parseInt(data.machineId));
          const sync_mysql = await app.sqlQuery(app.mysqlPool, 'SELECT * FROM `data_manager`.`sync_mysql` WHERE `machineId` = ' + client.machineId);
          client.sync_mysql = sync_mysql.response;


          // Return
          socket.emit(data.channel, { complete: true });

          break;

        case 'save-machine-info':
          // Find client
          const client1 = app.clients.find((client) => client.machineId === parseInt(data.machineId));
          // Error handling
          if (client1 === undefined) {
            socket.emit(data.channel, { error: 'Böyle bir kullanıcı bulunamadı' });
            return;
          }
          // Success return
          if (client1 !== undefined) {
            client1.name = data.name;
            client1.ip = data.ip;
            const saveMachineInfoSql = await app.sqlQuery(app.mysqlPool, 'UPDATE `data_manager`.`machines` SET `name`="' + data.name + '",`ip`="' + data.ip + '" WHERE `machineId`= ' + client1.machineId);
            if (saveMachineInfoSql.result) {
              socket.emit(data.channel, { success: 'Bilgiler başarıyla kaydedildi' });
              return;
            }
          }
          break;

        default:
          break;
      }

    });


    // (Router) Client run
    socket.on('client-run', async (data) => {

      /****** Router - Start ******/
      if (data.method === 'request') {
        // Find client from machineId
        const client = app.clients.find((client) => client.machineId === parseInt(data.machineId));
        // Emit data to all sockets of the client
        if (client !== undefined) {
          client.sockets.forEach((socketId, i) => {
            socket.to(socketId).emit('client-run', data);
          });
        } else {
          console.log('Client not found. Received data:', data);
        }
      }
      /****** Router - End ******/


      // (Catch) Client response
      if (data.method === 'response') {
        switch (data.channel) {

          case 'mysql-data-structure':

            // let sampleStructure = [
            //   {
            //     database: 'sm_016',
            //     tables: [
            //       { table: 'ateqtest', fields: ['id', 'kacak', 'sonuc', 'tarih'], createCommand: 'SHOW CREATE TABLE ...' },
            //       { table: 'soguktest', fields: ['id', 'kacak', 'sonuc', 'tarih'], createCommand: 'SHOW CREATE TABLE ...' },
            //     ]
            //   },
            //   {
            //     database: 'xc_019',
            //     tables: [
            //       { table: 'banko1', fields: ['id', 'pres', 'sonuc', 'tarih'], createCommand: 'SHOW CREATE TABLE ...' },
            //       { table: 'banko2', fields: ['id', 'pres', 'sonuc', 'tarih'], createCommand: 'SHOW CREATE TABLE ...' },
            //     ]
            //   }
            // ];

            // Clarify clientStructure
            data.clientStructure = data.result;
            // Delete already duplicated clientStructure
            delete data.result;
            // Parse machineId
            const machineId = parseInt(data.machineId);
            // Find client by machineId
            const client = app.clients.find((client) => client.machineId === machineId);
            // Get sync_mysql results again
            const sync_mysql = await app.sqlQuery(app.mysqlPool, 'SELECT * FROM `data_manager`.`sync_mysql` WHERE `machineId` = ' + machineId);
            // Update sync_mysql for client
            client.sync_mysql = sync_mysql.response;
            // Convert SQL data rows to same pattern with clientStructure
            data.serverStructure = app.convertRowsToStructure(client.sync_mysql);
            // Return
            socket.to(data.requester).emit(data.channel, data);
            break;

          // case 'mysql-tables-for-register':
          //   // Combine all SQL affairs
          //   data.result.response.forEach((item, i) => {
          //     // Use rename parameter for mysqlSanitizeStatement
          //     const convertedQuery = app.mysqlSanitizeStatement(item.clientQuery, `CREATE TABLE \`${data.serverDb}\`.\`${item.table}\``) ?? { statement: null, errors: null };
          //     item.serverQuery = convertedQuery.statement;
          //     item.errors = convertedQuery.errors;
          //   });
          //   // Return data to user
          //   socket.to(data.requester).emit(data.channel, data);
          //   break;

          default:
            socket.to(data.requester).emit(data.channel, data);
            break;

        }
      }
    });


    socket.on('app', async (data) => {
      socket.emit('app', { users: app.users, clients: app.clients, credentials: app.credentials });
    });


    socket.on('sync-mysql', async (data) => {

      for (const item of data) {
        const client = app.clients.find((client) => client.machineId == parseInt(item.machineId));
        if (client !== undefined) {
          const syncItem = client.sync_mysql.find((el) => el.syncId == parseInt(item.syncId));
          if (syncItem !== undefined) {

            for (const row of item.clientReponse.rows) {

              let keys = '';
              let values = '';

              for (const [key, value] of Object.entries(row)) {
                keys += `\`${key}\`, `;
                values += `${typeof row[key] === 'string' ? "'" + value + "'" : value}, `;
              }

              keys = keys.slice(0, -2);
              values = values.slice(0, -2);

              let query = `INSERT INTO \`${item.serverDatabase}\`.\`${item.serverTable}\` (${keys}) VALUES (${values});`;
              await app.sqlQuery(app.mysqlPool, query);
            }

            const clientLastRecord = item.clientReponse.counter[0].clientLastRecord;
            syncItem.clientLastRecord = clientLastRecord;

            const counter = await app.sqlQuery(app.mysqlPool, `SELECT COUNT(*) AS serverLastRecord FROM \`${item.serverDatabase}\`.\`${item.serverTable}\`;`);
            const serverLastRecord = counter.response[0].serverLastRecord;

            syncItem.clientLastRecord = clientLastRecord;
            syncItem.serverLastRecord = serverLastRecord;

            await app.sqlQuery(app.mysqlPool, 'UPDATE `data_manager`.`sync_mysql` SET `clientLastRecord` = ' + clientLastRecord + ', `serverLastRecord` = ' + serverLastRecord + ' WHERE `syncId` = ' + syncItem.syncId);

          }
        }
      }

    });




    // socket.on('server-databases', async (data) => {
    //   const rows = await app.sqlQuery(app.mysqlPool, `SHOW DATABASES;`);
    //   socket.emit('server-databases', rows);
    // });


    // socket.on('registration', async (data) => {
    //   console.log(data);



    //   // const data = {
    //   //   machineId: getMachineId(),
    //   //   name: machineName.value.trim(),
    //   //   ip: machineIp.value.trim(),
    //   //   clientDatabase: clientDatabase.value.trim(),
    //   //   serverDatabase: serverDatabase.value.trim(),
    //   //   clientTables: clientTables
    //   // };

    //   // Find client from machineId
    //   const client = app.clients.find((client) => client.machineId === parseInt(data.machineId));

    //   if (client !== undefined) {

    //     let eval = {
    //       totalTables: data.clientTables.length,
    //       succeedTables: 0,
    //       errors: 0,
    //       compatibility: 0,
    //     };

    //     // Registration info
    //     // Client bilgileri SQL'e kaydedilecek

    //     let rows = null;

    //     // Create database
    //     rows = await app.sqlQuery(app.mysqlPool, `CREATE DATABASE \`${data.serverDatabase}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;`);
    //     rows.info = `${data.serverDatabase} veritabanı oluşturuluyor`;
    //     rows.isTable = false;
    //     socket.emit('registration', rows);

    //     for (const item of data.clientTables) {
    //       // Drop table 
    //       let dropTable = await app.sqlQuery(app.mysqlPool, `DROP TABLE IF EXISTS \`${data.serverDatabase}\`.\`${item.table}\`;`);
    //       // Create table
    //       rows = await app.sqlQuery(app.mysqlPool, item.serverQuery);
    //       // Notification message
    //       rows.info = `${item.table} tablosu oluşturuluyor`;
    //       rows.isTable = true;
    //       rows.item = item;
    //       // Nofity
    //       socket.emit('registration', rows);
    //       // Update eval
    //       eval.errors += parseInt(item.errors);
    //       eval.succeedTables += rows.result ? 1 : 0;
    //     }

    //     let compatibility = Math.floor((eval.succeedTables / eval.totalTables) * 100);
    //     eval.compatibility = compatibility - eval.errors;

    //     socket.emit('registration', { info: 'Eşleştirme tamamlandı. Uyum %' + eval.compatibility, eval: eval });

    //   }
    // });

  });
}












