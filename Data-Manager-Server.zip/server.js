/**
 * @ Author: Erman İlçin
 * @ Create Time: 2024-04-16 13:38:40
 * @ Modified by: Erman İlçin
 * @ Modified time: 2024-05-24 00:47:11
 * @ Description: Data Manager Project
 */

const { createServer } = require('http');
const { Server } = require('socket.io');

const DOMAIN = 'localhost';
const PORT = 5000;

const httpServer = createServer();

const io = new Server(httpServer, {
    cors: {
        origin: `http://${DOMAIN}:${PORT}`,
        methods: ['GET', 'POST']
    },
    maxHttpBufferSize: 1e8 // 100MB
});

httpServer.listen(PORT, () => {
    console.log('Listening on *:', PORT);
});

module.exports = io;