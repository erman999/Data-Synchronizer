/**
 * @ Author: Erman İlçin
 * @ Create Time: 2024-04-23 22:40:14
 * @ Modified by: Erman İlçin
 * @ Modified time: 2024-05-24 00:47:05
 * @ Description: Data Manager Project
 */

const mysql = require('mysql2');

module.exports = new Promise(async (resolve, reject) => {
  try {
    console.log("[MySQL2] Trying to connect database...");
    const pool = mysql.createPool({ host: 'localhost', user: 'root', password: 'usbw', dateStrings: true });
    const promisePool = pool.promise();
    const [rows, fields] = await promisePool.query("SELECT 1 AS connection;");
    const result = parseInt(rows[0].connection) == 1 ? '[MySQL2] Connected to database' : false;
    console.log(result);
    resolve(promisePool);
  } catch (e) {
    console.log('[MySQL2] Failed to connect to database');
    reject(false);
  }
});